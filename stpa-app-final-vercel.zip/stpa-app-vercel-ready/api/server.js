const express = require('express');
const app = express();
const path = require('path');
const serverless = require('serverless-http');
const http = require('http');
const socketIo = require('socket.io');

const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, '../public')));

io.on('connection', (socket) => {
    console.log('Un utilisateur connecté');

    socket.on('update-table', (data) => {
        socket.broadcast.emit('update-table', data);
    });

    socket.on('chat-message', (msg) => {
        socket.broadcast.emit('chat-message', msg);
    });

    socket.on('disconnect', () => {
        console.log('Utilisateur déconnecté');
    });
});

module.exports = serverless(app);